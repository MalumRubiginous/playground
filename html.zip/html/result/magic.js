(function(document, window){
    const heads = document.querySelectorAll('h2');
    const sections = document.querySelectorAll('section');

    function doSomething(scroll_pos) {
        if (scroll_pos >= 0 && scroll_pos < 560) {
            heads[0].classList.add('sticky');
            sections[0].classList.add('sticky');
        } else {
            heads[0].classList.remove('sticky');
            heads[0].classList.remove('smooth');
            sections[0].classList.remove('sticky');
        }

        if (scroll_pos >= 560 && scroll_pos < 1476) {
            heads[1].classList.add('sticky');
        } else {
            heads[1].classList.remove('sticky');
        }

        if (scroll_pos >= 1476) {
            heads[2].classList.add('sticky');
        } else {
            heads[2].classList.remove('sticky');
        }
    }


    let last_known_scroll_position = 0;
    let ticking = false;
    window.addEventListener('scroll', function(e) {
        last_known_scroll_position = window.scrollY;
        if (!ticking) {
            window.requestAnimationFrame(function() {
                doSomething(last_known_scroll_position);
                ticking = false;
            });
        }
        ticking = true;
    });

    document.addEventListener('keydown', function(e) {
        if (e.keyCode === 27) {
            document.body.classList.toggle('magic');
        }
    });

    const toggler = document.getElementById('toggler');
    toggler.addEventListener('click', function(e) {
        document.body.classList.toggle('magic');
    });

})(document, window);

