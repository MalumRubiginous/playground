var stars = document.getElementsByClassName('star');
var submit = document.getElementById('btn');
var score = document.getElementById('score');
var rate = 0, isSubmited = false;

submit.addEventListener('click', function(e){
    isSubmited = true;
    e.target.style.display = 'none';
    score.innerHTML = rate;
});

Array.prototype.forEach.call(stars, function(star, index){
    star.addEventListener('mouseenter', function(){
      if (isSubmited) {return ;}
      for(var i = 0; i < index + 1; i++) {
          stars[i].classList.add('fill');
      }
  });

  star.addEventListener('mouseout', function(){
      if (isSubmited) {return ;}
      for(var i = rate; i < 5; i++) {
          stars[i].classList.remove('fill');
      }
  });

  star.addEventListener('click', function(e){
      if (isSubmited) {return ;}
        rate = index + 1;
      for(var i = 0; i < 5; i++) {
          stars[i].classList.remove('fill');
      }
      for(var i = 0; i < index + 1; i++) {
          stars[i].classList.add('fill');
      }
  });
});
